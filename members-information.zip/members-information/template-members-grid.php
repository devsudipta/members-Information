<?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$per_page = 20;

$args = array(
    'post_type'      => 'member',
    'posts_per_page' => $per_page,
    'paged'          => $paged,
);

$query = new WP_Query($args);

if ($query->have_posts()) :
    ?>
    <div class="members-directory">
        <div class="members-search-filter">
            <input type="text" id="members-search" placeholder="Search members...">
            <select id="members-filter">
                <option value="">All Categories</option>
                <?php
                $categories = array_unique(array_filter(array_map(function ($post) {
                    return get_post_meta($post->ID, 'membership_category', true);
                }, $query->posts)));
                foreach ($categories as $category) :
                    echo '<option value="' . esc_attr($category) . '">' . esc_html($category) . '</option>';
                endforeach;
                ?>
            </select>
        </div>
        <div class="members-list">
            <?php
            while ($query->have_posts()) : $query->the_post();
                $membership_id = get_post_meta(get_the_ID(), 'membership_id', true);
                $membership_category = get_post_meta(get_the_ID(), 'membership_category', true);
                $joining_year = get_post_meta(get_the_ID(), 'joining_year', true);
                ?>
          <div class="member-card">
                    <div class="member-image">
                        <?php the_post_thumbnail('medium'); ?>
                    </div>
                    <div class="member-details">
                        <h3 class="member-name"><?php the_title(); ?></h3>
                        <p class="member-id">Membership ID: <?php echo esc_html($membership_id); ?></p>
                        <p class="member-category">Category: <?php echo esc_html($membership_category); ?></p>
                        <p class="member-year">Joining Year: <?php echo esc_html($joining_year); ?></p>
                    </div>
                </div>
                
                
            <?php endwhile; ?>
        </div>
        <div class="members-pagination">
            <?php
            echo paginate_links(array(
                'total'   => $query->max_num_pages,
                'current' => $paged,
            ));
            ?>
        </div>
    </div>
    <?php
    wp_reset_postdata();
else :
    echo '<p>No members found.</p>';
endif;
?>