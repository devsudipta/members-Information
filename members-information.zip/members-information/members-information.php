<?php
/*
Plugin Name: Members Information
Description: Displays member information in a grid with search, filter, and pagination.
Version: 1.0
Author: Sudipta Roy Akash
Author URI: https://www.sudiptaroy.info 
Text Domain: members-information
License: GPL2+
*/

/*
 * Members Information
 * 
 * Displays member information in a grid with search, filter, and pagination.
 * 
 * @package Members Information
 * @version 1.0
 * @category Core
 * @author Sudipta Roy Akash
 * @link https://www.sudiptaroy.info
 * @license GPL2+  
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/class-members-information-cpt.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-members-information-meta.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-members-information-shortcode.php';

// Instantiate classes
new Members_Information_CPT();
new Members_Information_Meta();
new Members_Information_Shortcode();

// Enqueue styles and scripts
function members_information_enqueue_scripts() {
    wp_enqueue_style('members-information-style', plugin_dir_url(__FILE__) . 'assets/css/members-information.css');
    wp_enqueue_script('members-information-script', plugin_dir_url(__FILE__) . 'assets/js/members-information.js', array('jquery'), '1.0', true);
    wp_localize_script('members-information-script', 'members_information_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'members_information_enqueue_scripts');
?>