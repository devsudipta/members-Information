<?php
if (!defined('ABSPATH')) {
    exit;
}

class Members_Information_Shortcode {
    public function __construct() {
        add_shortcode('members_grid', array($this, 'members_grid_shortcode'));
    }

    public function members_grid_shortcode($atts) {
        ob_start();
        include plugin_dir_path(dirname(__FILE__)) . 'template-members-grid.php';
        return ob_get_clean();
    }
}
?>