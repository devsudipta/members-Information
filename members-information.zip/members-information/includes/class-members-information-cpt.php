<?php
if (!defined('ABSPATH')) {
    exit;
}

class Members_Information_CPT {
    public function __construct() {
        add_action('init', array($this, 'register_member_post_type'));
        add_filter('post_updated_messages', array($this, 'member_updated_messages'));
        add_filter('manage_member_posts_columns', array($this, 'set_custom_columns'));
        add_action('manage_member_posts_custom_column', array($this, 'custom_member_columns'), 10, 2);
    }

    public function register_member_post_type() {
        $labels = array(
            'name'               => _x('Members', 'post type general name', 'members-information'),
            'singular_name'      => _x('Member', 'post type singular name', 'members-information'),
            'menu_name'          => _x('Members', 'admin menu', 'members-information'),
            'name_admin_bar'     => _x('Member', 'add new on admin bar', 'members-information'),
            'add_new'            => _x('Add Member', 'member', 'members-information'),
            'add_new_item'       => __('Add New Member', 'members-information'),
            'new_item'           => __('New Member', 'members-information'),
            'edit_item'          => __('Edit Member', 'members-information'),
            'view_item'          => __('View Member', 'members-information'),
            'all_items'          => __('All Members', 'members-information'),
            'search_items'       => __('Search Members', 'members-information'),
            'parent_item_colon'  => __('Parent Members:', 'members-information'),
            'not_found'          => __('No members found.', 'members-information'),
            'not_found_in_trash' => __('No members found in Trash.', 'members-information')
    
        );
        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'member'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20, // Adjust menu position as needed
            'menu_icon'          => 'dashicons-groups', // Choose an appropriate dashicon
            'supports'           => array('title', 'thumbnail')
        );
        
        register_post_type('member', $args);
    }

    public function member_updated_messages($messages) {
        global $post;
        $post_ID = isset($post->ID) ? absint($post->ID) : 0;
        $messages['member'] = array(
            0  => '',
            1  => __('Member updated.', 'members-information'),
            2  => __('Custom field updated.', 'members-information'),
            3  => __('Custom field deleted.', 'members-information'),
            4  => __('Member updated.', 'members-information'),
            5  => isset($_GET['revision']) ? sprintf(__('Member restored to revision from %s', 'members-information'), wp_post_revision_title((int) $_GET['revision'], false)) : false,
            6  => __('Member published.', 'members-information'),
            7  => __('Member saved.', 'members-information'),
            8  => __('Member submitted.', 'members-information'),
            9  => sprintf(__('Member scheduled for: <strong>%1$s</strong>.', 'members-information'), date_i18n(__('M j, Y @ G:i'), strtotime($post->post_date))),
            10 => __('Member draft updated.', 'members-information')
        );
        return $messages;
    }

    public function set_custom_columns($columns) {
        unset($columns['date']);
        $columns['thumbnail'] = __('Image', 'members-information');
        $columns['membership_id'] = __('Membership ID', 'members-information');
        $columns['membership_category'] = __('Category', 'members-information');
        $columns['joining_year'] = __('Joining Year', 'members-information');
        return $columns;
    }

    public function custom_member_columns($column, $post_id) {
        switch ($column) {
            case 'thumbnail':
                if (has_post_thumbnail($post_id)) {
                    the_post_thumbnail('thumbnail', array('style' => 'max-width: 50px;'));
                }
                break;
            case 'membership_id':
                echo esc_html(get_post_meta($post_id, 'membership_id', true));
                break;
            case 'membership_category':
                echo esc_html(get_post_meta($post_id, 'membership_category', true));
                break;
            case 'joining_year':
                echo esc_html(get_post_meta($post_id, 'joining_year', true));
                break;
        }
    }
}
?>