<?php
if (!defined('ABSPATH')) {
    exit;
}

class Members_Information_Meta {
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_member_meta_boxes'));
        add_action('save_post', array($this, 'save_member_meta_data'));
    }

    public function add_member_meta_boxes() {
        add_meta_box(
            'member_details',
            'Member Details',
            array($this, 'member_details_meta_box_callback'),
            'member'
        );
    }

    public function member_details_meta_box_callback($post) {
        wp_nonce_field('member_details_nonce', 'member_details_nonce');
        $membership_id = get_post_meta($post->ID, 'membership_id', true);
        $membership_category = get_post_meta($post->ID, 'membership_category', true);
        $joining_year = get_post_meta($post->ID, 'joining_year', true);
        ?>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="membership_id">Membership ID:</label></th>
                <td><input type="text" id="membership_id" name="membership_id" value="<?php echo esc_attr($membership_id); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label for="membership_category">Membership Category:</label></th>
                <td><input type="text" id="membership_category" name="membership_category" value="<?php echo esc_attr($membership_category); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label for="joining_year">Joining Year:</label></th>
                <td><input type="number" id="joining_year" name="joining_year" value="<?php echo esc_attr($joining_year); ?>" class="small-text"></td>
            </tr>
        </table>
        <?php
    }

    public function save_member_meta_data($post_id) {
        if (!isset($_POST['member_details_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['member_details_nonce'], 'member_details_nonce')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if (isset($_POST['membership_id'])) {
            update_post_meta($post_id, 'membership_id', sanitize_text_field($_POST['membership_id']));
        }
        if (isset($_POST['membership_category'])) {
            update_post_meta($post_id, 'membership_category', sanitize_text_field($_POST['membership_category']));
        }
        if (isset($_POST['joining_year'])) {
            update_post_meta($post_id, 'joining_year', intval($_POST['joining_year']));
        }
    }
}
?>