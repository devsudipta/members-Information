jQuery(document).ready(function($) {
    $('#members-search, #members-filter').on('input', function() {
        var search = $('#members-search').val().toLowerCase();
        var filter = $('#members-filter').val().toLowerCase();

        $('.member-card').each(function() {
            var title = $(this).find('h3').text().toLowerCase();
            var category = $(this).find('p:contains("Category:")').text().toLowerCase();

            if (title.indexOf(search) > -1 && (filter === '' || category.indexOf(filter) > -1)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
});